
"use strict";

let edge_detect = require('./edge_detect.js')

module.exports = {
  edge_detect: edge_detect,
};
