// Auto-generated. Do not edit!

// (in-package edge_detection.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class edge_detectRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.input_img_path = null;
    }
    else {
      if (initObj.hasOwnProperty('input_img_path')) {
        this.input_img_path = initObj.input_img_path
      }
      else {
        this.input_img_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type edge_detectRequest
    // Serialize message field [input_img_path]
    bufferOffset = _serializer.string(obj.input_img_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type edge_detectRequest
    let len;
    let data = new edge_detectRequest(null);
    // Deserialize message field [input_img_path]
    data.input_img_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.input_img_path);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'edge_detection/edge_detectRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '749cb9e0d45c78eff3563b6c2f710ff6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string input_img_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new edge_detectRequest(null);
    if (msg.input_img_path !== undefined) {
      resolved.input_img_path = msg.input_img_path;
    }
    else {
      resolved.input_img_path = ''
    }

    return resolved;
    }
};

class edge_detectResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.output_img_path = null;
    }
    else {
      if (initObj.hasOwnProperty('output_img_path')) {
        this.output_img_path = initObj.output_img_path
      }
      else {
        this.output_img_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type edge_detectResponse
    // Serialize message field [output_img_path]
    bufferOffset = _serializer.string(obj.output_img_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type edge_detectResponse
    let len;
    let data = new edge_detectResponse(null);
    // Deserialize message field [output_img_path]
    data.output_img_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.output_img_path);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'edge_detection/edge_detectResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd18a7f29fb5f7ef6155b830b6413961f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string output_img_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new edge_detectResponse(null);
    if (msg.output_img_path !== undefined) {
      resolved.output_img_path = msg.output_img_path;
    }
    else {
      resolved.output_img_path = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: edge_detectRequest,
  Response: edge_detectResponse,
  md5sum() { return '1de86861d5e14616d72b2a90bfd23646'; },
  datatype() { return 'edge_detection/edge_detect'; }
};
