
"use strict";

let Image_data = require('./Image_data.js');

module.exports = {
  Image_data: Image_data,
};
