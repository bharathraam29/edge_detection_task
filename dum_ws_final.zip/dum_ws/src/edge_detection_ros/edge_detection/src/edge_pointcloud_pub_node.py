#!/usr/bin/env python3
import cv2
import numpy as np
import rospy
from sensor_msgs.msg import PointCloud,Image,CameraInfo
from geometry_msgs.msg import Point32,Point,PointStamped
from cv_bridge import CvBridge,CvBridgeError
import message_filters
from visualization_msgs.msg import Marker
from tf2_msgs.msg import TFMessage
from tf import TransformListener
import tf

def Edge_detected_3D_point_cloud_gen(color_img:Image, depth_image:Image,camera_info:CameraInfo):
    rospy.loginfo("Generating point cloud of edge detected image")
    bridge_obj=CvBridge()
    img=bridge_obj.imgmsg_to_cv2(color_img,desired_encoding='bgr8')
    gray= cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # get coordinates (x,y) of all green pixels (aka edges)
    xy_coords = np.flip(np.column_stack(np.where(gray >0)), axis=1)


    #get camera info      
    camera_info_K = np.array(camera_info.K)
    # Intrinsic camera matrix for the raw (distorted) images.
    #     [fx  0 cx]
    # K = [ 0 fy cy]
    #     [ 0  0  1]
    
    m_fx = camera_info.K[0]
    m_fy = camera_info.K[4]
    m_cx = camera_info.K[2]
    m_cy = camera_info.K[5]
    inv_fx = 1. / m_fx
    inv_fy = 1. / m_fy

    #getting depth details
    depth_image_cv = bridge_obj.imgmsg_to_cv2(depth_image, "32FC1")
    depth_array = np.array(depth_image_cv, dtype=np.float32)

    cv2.normalize(depth_array, depth_array, 0, 1, cv2.NORM_MINMAX)
    depth_8 = (depth_array * 255).round().astype(np.uint8)
    cv_depth = np.zeros_like(img)
    cv_depth[:,:,0] = depth_8
    cv_depth[:,:,1] = depth_8
    cv_depth[:,:,2] = depth_8
    rgb_height, rgb_width, rgb_channels = img.shape

    #declare a point cloud 
    Edge_detected_pointcloud = PointCloud()
    Edge_detected_pointcloud.header=color_img.header
    edge_3d_marker=Marker()
    edge_3d_marker.header=camera_info.header
    edge_3d_marker.lifetime=rospy.Duration(0)
    edge_3d_marker.type=Marker.SPHERE
    id=0
    my_point=Point()
    edge_3d_marker.color.r=0
    edge_3d_marker.color.g=255
    edge_3d_marker.color.b=0
    edge_3d_marker.color.a=1

    edge_3d_marker.scale.x=0.1
    edge_3d_marker.scale.y=0.1
    edge_3d_marker.scale.z=0.1

    #Calculating X,Y,Z from x,y using K matrix
    for x,y in xy_coords:
        '''
        uncomment if needed to average depth over 3x3 kernel
        roi_depth = depth_image_cv[y-1:y+1, x-1:x+1] #if we pad the image we can use a averaging kernel to determine mean_z
        n = 1
        sum = 0
        for i in range(0,roi_depth.shape[0]):
            for j in range(0,roi_depth.shape[1]):
                value = roi_depth.item(i, j)
                if value > 0.:
                    n = n + 1
                    sum = sum + value
        if sum:
            mean_z = sum / n
        else:
            mean_z=depth_image_cv[y,x]
        print('Mean_z= ',mean_z,"  roi_depth: ",depth_image_cv[y,x])
        '''
        mean_z=depth_image_cv[y,x]
        point_z = mean_z * 0.001 # distance in meters
        point_x = ((x) - m_cx) * point_z * inv_fx
        point_y = ((y) - m_cy) * point_z * inv_fy
        #edge_3d_marker.pose.position=Point(point_x,point_y,point_z)
        Edge_detected_pointcloud.points.append(Point32(point_x,point_y,point_z))
        
        edge_3d_marker.id=id
        id+=1
        #publish rviz marker
        
        my_point.x=point_x
        my_point.y=point_y
        my_point.z=point_z
        
        tf_obj=TransformListener()
        #tf_obj._listener='tf_static'
        #target_frame="world"
        #source_frame="camera_color_optical_frame"
        #my_point_stamped=PointStamped()
        #my_point_stamped.header=camera_info.header
        #my_point_stamped.point=my_point
        #if (tf_obj.canTransform(source_frame,target_frame,rospy.Duration(0))):
        #    print('yes')
        #mypoint=tf_obj.transformPoint(target_frame,my_point_stamped).point
        #edge_3d_marker.points.append(my_point)

        #edge_3d_marker.colors.append(edge_3d_marker.color)
        
        #edge_3d_marker.header.frame_id='target_frame'


        edge_3d_marker.pose.position=my_point
        edge_3d_marker_pub.publish(edge_3d_marker)     

    #publish pointcloud
     
    edge_detected_3D_point_cloud_pub.publish(Edge_detected_pointcloud)



def edge_detected_image_listener():
    rospy.init_node('edge_detected_image_listener')
    edge_detected_image_sub=message_filters.Subscriber('edge_detected_image',Image)
    camera_info_sub = message_filters.Subscriber('/camera/color/camera_info', CameraInfo)
    depth_image_sub= message_filters.Subscriber('/camera/depth/image_rect_raw', Image)
    
    ts = message_filters.ApproximateTimeSynchronizer([edge_detected_image_sub, depth_image_sub, camera_info_sub], queue_size=10, slop=1,allow_headerless=True)
    ts.registerCallback(Edge_detected_3D_point_cloud_gen)

    rospy.spin()
    pass


if __name__=='__main__':
    edge_detected_3D_point_cloud_pub = rospy.Publisher('edge_points',PointCloud,queue_size=10)
    edge_3d_marker_pub=rospy.Publisher('edge_3D_marker',Marker,queue_size=10)
    edge_detected_image_listener()