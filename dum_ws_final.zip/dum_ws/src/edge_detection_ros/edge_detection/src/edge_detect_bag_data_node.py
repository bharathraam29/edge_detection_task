#!/usr/bin/env python3


import rospy
import cv2 as cv

from edge_detector import edge_detector
from sensor_msgs.msg import Image
from cv_bridge import CvBridge,CvBridgeError

def Image_raw_processor(data:Image):
    rospy.loginfo("Rx Data")
    edge_img=edge_detector()
    bridge_object=CvBridge()
    cv_image= bridge_object.imgmsg_to_cv2(data,desired_encoding='bgr8')
    edge_detected_img=edge_img.edge_detect(cv_image)
    edge_detected_img_msg=bridge_object.cv2_to_imgmsg(edge_detected_img,encoding='bgr8')  
    edge_detected_img_msg.header=data.header
    edge_detect_img_pub.publish(edge_detected_img_msg)


def Image_raw_listener():
    rospy.init_node('image_raw_listener')
    
    image_sub=rospy.Subscriber('/camera/color/image_raw',Image, callback=Image_raw_processor, buff_size=10)
    rospy.spin()
    pass

if __name__=='__main__':
    edge_detect_img_pub=rospy.Publisher('edge_detected_image',Image,queue_size=10)
    Image_raw_listener()
    


