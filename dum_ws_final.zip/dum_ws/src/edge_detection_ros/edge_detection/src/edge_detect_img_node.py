#!/usr/bin/env python3

# This Service takes in a Image and detects edges # 

import rospy
import cv2 as cv
from edge_detection.srv import edge_detect, edge_detectResponse
from edge_detector import edge_detector

def edge_detect_image_callback(request):
    rospy.loginfo(request.input_img_path)

    img=cv.imread(request.input_img_path)
    edge_detector_obj=edge_detector()
    result_img=edge_detector_obj.edge_detect(img)
    cv.imwrite('/home/vboxuser/dum_ws/src/edge_detection_ros/edge_detection/data/op_edge.png',result_img)
    return edge_detectResponse('//home/vboxuser/dum_ws/src/edge_detection_ros/edge_detection/data/op_edge.png')

def edge_detect_image_func():
    rospy.init_node('Image_edge_detect_service')
    service=rospy.Service('Image_edge_detect_service', edge_detect, edge_detect_image_callback)
    rospy.loginfo("Image_edge_detect_service is live...")
    rospy.spin()

if __name__=='__main__':
    edge_detect_image_func()
