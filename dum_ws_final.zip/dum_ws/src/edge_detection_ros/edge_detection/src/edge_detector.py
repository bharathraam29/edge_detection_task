#!/usr/bin/env python3
import rospy
import cv2 as cv
import numpy as np
from cv_bridge import CvBridge , CvBridgeError
from sensor_msgs.msg import Image, CameraInfo


class edge_detector():
    def __init__(self):
        self.img=None
        pass

    def edge_detect(self,image_raw, edge_detector_filter_type=0):
        #edge_detector_filter_type =0 --> canny
        #edge_detector_filter_type =1 --> laplacian
        self.img=image_raw
        self.img_gray=cv.cvtColor(self.img,cv.COLOR_BGR2GRAY) # Convert image to grayscale
        blur_img= cv.GaussianBlur(self.img_gray,(5,5),0) #Removing Gaussion noise to get well defined edges
        if(edge_detector_filter_type==0):
            self.edge_detected_img= cv.Canny(blur_img,150,150)
        elif(edge_detector_filter_type==1):
            self.edge_detected_img= cv.Laplacian(blur_img, cv.CV_8U)
        
        self.edge_detected_img= cv.cvtColor(self.edge_detected_img,cv.COLOR_GRAY2BGR)
        self.edge_detected_img[np.all(self.edge_detected_img == (255,255,255), axis=-1)] = (0,255,0) #--> making all white pixels green
        
        #cv.imwrite('/home/vboxuser/Downloads/op.png',self.edge_detected_img) #--> debugging purposes

#        A novel approach to overlay canny and Laplacian results.
#        lap= cv.Laplacian(blur_img, cv.CV_8U)  --> laplacian edge filter
#        dst = cv.addWeighted(lap,0.5,self.edge_detected_img,0.7,0) -->trying to overlay laplacian and canny results
#        cv.imwrite('/home/vboxuser/Downloads/dst.png',dst) 
#        cv.imwrite('/home/vboxuser/Downloads/lap_op.png',lap) 

### uncomment below to view the op in a separate window ###

#        while(1):
#            cv.imshow('op', self.edge_detected_img)
#
#            if cv.waitKey(5) ==ord('x'):
#                break 

        return self.edge_detected_img

def main():
    img_path=input("Enter Image path: ")
    img=cv.imread(img_path)
    edge_result= edge_detector()
    edge_result.edge_detect(img)

#main()  --> uncomment to run main func
