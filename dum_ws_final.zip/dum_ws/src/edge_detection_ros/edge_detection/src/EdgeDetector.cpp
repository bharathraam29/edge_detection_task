#include <edge_detection/EdgeDetector.hpp>

using namespace edge_detection;

// Your class methods definition goes here




int main()
{
	edge_detection::EdgeDetector detector;
    // Create the executable for testing the code here

	return 0;
}
