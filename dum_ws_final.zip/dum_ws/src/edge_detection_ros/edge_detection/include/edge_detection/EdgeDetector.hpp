#pragma once

namespace edge_detection
{
class EdgeDetector
{
	// Your class declaration goes here 
};

}
