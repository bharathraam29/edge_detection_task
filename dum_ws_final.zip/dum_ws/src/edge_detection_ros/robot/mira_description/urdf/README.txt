# Mira:

- export BASE_LINK="1"  # 
- export EEF_LINK="10"  # ee_link
- export FREE_INDEX="4" # joint3

- only change this file: mira.urdf.xacro, parameter_file_name (default is "mira")
- this refers to mira.xacro file containing the parameters

